import logging

from odoo import http, _, fields
from odoo.http import request
from datetime import datetime
import json

_logger = logging.getLogger(__name__)

class MasterRuanganAPI(http.Controller):
    @http.route('/api/create-master-ruangan', type='json', auth='user', methods=['POST'], csrf=False)
    def create_edit_sales_customer(self, **post):
        master_ruangan = self.env['master.ruangan'].sudo()
        respons = False
        if post:
            try:
                cretate_master = master_ruangan.create({
                    'name': post['name'],
                    'tipe_ruangan': post['tipe_ruangan'],
                    'lokasi_ruangan': post['lokasi_ruangan'],
                    'kapasitas_ruangan': post['kapasitas_ruangan']
                })    

                respons = self.respon_messages_list(200, True, 'Success Create Master Ruangan : %s' % (cretate_master.name), post)
            except Exception as exc:
                respons = self.respon_messages_list(400, False, exc, [])
        
            respons_json = json.dumps(respons)
            headers = {
                'Content-Type': 'application/json',
            }
            return http.Response(response=respons_json, status=200, headers=headers)
    