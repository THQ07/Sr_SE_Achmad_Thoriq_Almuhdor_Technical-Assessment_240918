# -*- coding: utf-8 -*-
{
    'name': "Odoo 17 - Assessment (Extension)",

    'summary': """Odoo 17 - Assessment (Extension)""",

    'description': """
        Assessment
    """,

    'author': "THQ Inc.",
    'website': "http://www.thcinc.com",
    'category': 'THQ',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': [
        'base',
    ],

    # always loaded
    'data': [
        # Security
        'security/ir.model.access.csv',
        # Data
        # Views
        'views/master_ruangan_views.xml',
        'views/pemesanan_ruangan_views.xml',
        # Wizard
    ],
    'qweb': [],
    # only loaded in demonstration mode
    'demo': [
    ],
}

