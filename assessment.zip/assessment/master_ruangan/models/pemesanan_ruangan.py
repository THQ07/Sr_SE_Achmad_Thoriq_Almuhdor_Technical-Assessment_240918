from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError
from odoo.http import request


class PemesananRuangan(models.Model):
    _name = 'pemesanan.ruangan'
    
    name = fields.Char(string="Nama Pemesanan")
    master_ruangan_id = fields.Many2one('master.ruangan',string="Master Ruangan")
    status_proses_pemesanan = fields.Selection(
        [
            ('draft','Draft'),
            ('ongoing','Ongoing'),
            ('done','Done')
        ],string="Proses Pemesanan", default='draft'
    )
    tanggal_pemesanan = fields.Date(string="Tanggal Pemesanan")
    catatan_pemesanan = fields.Text(string="Catatan Pemesanan")
    
    def update_status_ongoing(self):
        for record in self:
            record.update({
                'status_proses_pemesanan': 'ongoing'
            })
    
    def update_status_done(self):
        for record in self:
            record.update({
                'status_proses_pemesanan': 'done'
            })
            
    @api.constrains('name')
    def check_name(self):
        check_name_code = self.sudo().search([('name', 'ilike', self.name)])
        if len(check_name_code) > 1:
            raise ValidationError('You cant have same Name!')
        
    @api.constrains('master_ruangan_id','tanggal_pemesanan')
    def check_duplicate_unique(self):
        check_duplicate_unique = self.sudo().search([('master_ruangan_id', '=', self.master_ruangan_id.id),('tanggal_pemesanan','=',self.tanggal_pemesanan)])
        if len(check_duplicate_unique) > 1:
            raise ValidationError('Theres already same Ruangan and Date!')