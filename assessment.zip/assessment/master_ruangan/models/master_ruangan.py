from odoo import models, fields, api
from odoo.exceptions import ValidationError
from odoo.http import request


class MasterRuangan(models.Model):
    _name = 'master.ruangan'
    
    name = fields.Char(string="Nama Ruangan")
    tipe_ruangan = fields.Selection(
        [
            ('room_kecil','Meeting Room Kecil'),
            ('room_besar','Meeting Room Besar'),
            ('aula','Aula')
        ],string="Tipe Ruangan", default=False
    )
    lokasi_ruangan = fields.Selection(
        [
            ('1a','1A'),
            ('1b','1B'),
            ('1c','1C'),
            ('2a','2A'),
            ('2b','2B'),
            ('2c','2C'),
        ], string="Lokasi Ruangan", default=False
    )
    foto_ruangan = fields.Boolean(string="Foto Ruangan")
    kapasitas_ruangan = fields.Integer(string="Kapasitas Ruangan")
    keterangan = fields.Text(string="Keterangan")
    
    _sql_constraints = [('name_unique', 'unique(name)', "Nama ruangan must be unique.")]